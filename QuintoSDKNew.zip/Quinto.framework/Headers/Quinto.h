//
//  Quinto.h
//  Quinto
//
//  Created by Quinto Technologies Pvt. Ltd. on 31/07/17.
//  Copyright © 2017 Quinto Technologies Pvt. Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Quinto.
FOUNDATION_EXPORT double QuintoVersionNumber;

//! Project version string for Quinto.
FOUNDATION_EXPORT const unsigned char QuintoVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Quinto/PublicHeader.h>


